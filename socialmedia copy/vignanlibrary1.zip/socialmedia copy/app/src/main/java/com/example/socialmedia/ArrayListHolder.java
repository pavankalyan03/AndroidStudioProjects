package com.example.socialmedia;

import java.util.ArrayList;

public class ArrayListHolder {

    public static String current="";
    public static ArrayList<String> username = new ArrayList<String>();

    public   static ArrayList<String> password = new ArrayList<String>();

    public static   ArrayList<String> fullname = new ArrayList<String>();

    public static ArrayList<String> surname = new ArrayList<String>();

    public static ArrayList<String> dateofbirth = new ArrayList<String>();

    public static ArrayList<String> phoneno = new ArrayList<String>();



}
